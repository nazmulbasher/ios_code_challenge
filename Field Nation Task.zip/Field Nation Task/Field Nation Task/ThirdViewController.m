//
//  ThirdViewController.m
//  Field Nation Task
//
//  Created by Ashish on 1/23/15.
//  Copyright (c) 2015 Field Nation. All rights reserved.
//

#import "ThirdViewController.h"

@implementation ThirdViewController

@synthesize blueTableView, mySegmentedControl, footer;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //frame for the segemented button
    CGRect myFrame = CGRectMake(10.0f, 10.0f, 300.0f, 40.0f);
    
    //Array of items to go inside the segment control
    //You can choose to add an UIImage as one of the items instead of NSString
    NSArray *mySegments = [[NSArray alloc] initWithObjects: @"Field Nation",
                           @"iOS", nil];
    
    //create an intialize our segmented control
   mySegmentedControl = [[UISegmentedControl alloc] initWithItems:mySegments];
    
    //set the size and placement
    self.mySegmentedControl.frame = myFrame;
    
//    //set the style for the segmented control
//    self.mySegmentedControl.segmentedControlStyle  = UISegmentedControlStyleBar;
    
 CGRect myFrame2 = CGRectMake(10.0f, 10.0f, 300.0f, 40.0f);
        
    footer = [[UIImageView alloc] initWithFrame:CGRectZero];
    self.footer.frame = myFrame2;
    self.footer.backgroundColor = [UIColor whiteColor];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"SimpleTableItem";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = @"FIELDNATION";
    cell.backgroundColor=[UIColor orangeColor];
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    return mySegmentedControl;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 40.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return footer;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 40.0;
}

@end
