//
//  ThirdViewController.h
//  Field Nation Task
//
//  Created by Ashish on 1/23/15.
//  Copyright (c) 2015 Field Nation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThirdViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UITableView *blueTableView;
    UISegmentedControl *mySegmentedControl;
    UIImageView *footer;
}

@property (nonatomic, strong) UITableView *blueTableView;
@property (nonatomic, strong) UISegmentedControl *mySegmentedControl;
@property (nonatomic, strong) UIImageView *footer;

@end
